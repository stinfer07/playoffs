import pytest
from playoff_clases import *
from datetime import *
def nuevo_partido(equipo1,equipo2,fecha):
    Partido(fecha, [equipo1, equipo2])
def nueva_eliminatoria(equipo1, equipo2, fecha):
    lista_partidos = []
    for i in range(4):
        lista_partidos.append(Partido(fecha, [equipo1, equipo2]))
        fecha += timedelta(days=2)
def nuevo_ganador(self):
        contador_equipo1 = 0
        contador_equipo2 = 0
        for equipo in self.partidos:
            if equipo == self.equipos[0]:
                contador_equipo1 += 1
            elif equipo == self.equipos[1]:
                contador_equipo2 += 1
                
            if contador_equipo1 == 4:
                return self.equipos[0]
            elif contador_equipo2 == 4:
                return self.equipos[1]
def equipo():
    return Equipo()
def partido():
    return Partido()
def test_metodo():
    e = nueva_eliminatoria("Warriors", "Clippers", date(2019, 4, 29))
    p = nuevo_partido("Warriors", "Clippers", date(2019, 12, 31))
    assert e == None
    assert p == None
    